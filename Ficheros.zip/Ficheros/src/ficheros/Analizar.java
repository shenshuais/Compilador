
package ficheros;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileInputStream;  
import java.io.FileNotFoundException;  
import java.io.IOException;  
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.*;  
import org.apache.poi.ss.usermodel.Sheet;  
import org.apache.poi.ss.usermodel.Workbook;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook; 
public class Analizar {
    String linear="";
    
    public void verificarCode(String linea){
        this.linear=linea;
        Pattern comentarioP = Pattern.compile("^ *\\*+.*$");
        Matcher comentarioM = comentarioP.matcher(linear);
        Pattern variableP = Pattern.compile("^[^ *]+ +EQU +\\$[0-9A-F]{4}?( *\\*+.*)?$");
        Matcher variableM = variableP.matcher(linear);
        Pattern directivaP = Pattern.compile("^ +(ORG|END|FCB) +\\$[0-9A-F]{4}?( *\\*+.*)?$");// Tiene que se un numero hexadecimal?
        Matcher directivaM = directivaP.matcher(linear);
        Pattern etiquetaP = Pattern.compile("^[^ *]+( *\\*+.*)?$");
        Matcher etiquetaM = etiquetaP.matcher(linear);
        //modos de direccionamiento
        
        Pattern inherenteP = Pattern.compile("^ +[^ *]+( *\\*+.*)?$");
        Matcher inherenteM = inherenteP.matcher(linear);
        Pattern inmediatoP = Pattern.compile("^ +[^ *]+ +#((\\$(([0-9A-F]{2})|([0-9A-F]{4})))|('[\\p{ASCII}]{1,2})|(([\\d]{2})|([\\d]{4})))( *\\*+.*)?$");
        Matcher inmediatoM = inmediatoP.matcher(linear);
        Pattern directoP = Pattern.compile("^ +[^ *]+ +((\\$[0-9A-F]{2})|(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])))( *\\*+.*)?$");
        Matcher directoM = directoP.matcher(linear);
        Pattern extendidoP = Pattern.compile("^ +[^ *]+ +((\\$([0-9A-F]{4}))|([\\d]{3,5}))( *\\*+.*)?$");
        Matcher extendidoM = extendidoP.matcher(linear); 
        Pattern indexadoP = Pattern.compile("^ +[^ *]+ +\\\\$([0-9A-F]{2})\\\\,(X|Y|x|y)( *\\\\*+.*)?$");
        Matcher indexadoM = indexadoP.matcher(linear);  
        Pattern relativoP = Pattern.compile("^ +[^ *]+ +[^ *]+( *\\*+.*)?$");
        Matcher relativoM = relativoP.matcher(linear);
        
        //Faltaria las 4 exepciones. 
        
        //verifica si es una linea nula no es necesario hacer nada se agrega las lineas nulas
        if(linear.trim().equals("")){
            linear=" 0000";
        }
        //Verificación de codigo
        if(comentarioM.matches()){
            modificarComentario(linear);
        }
        
        
        //variable y constantes y gardarlo
        if(variableM.matches()){
            modificarVariable(linear);
            
            
        }
        
        //verificar si es una etiqueta
        if(etiquetaM.matches()){
            modificarEtiqueta(linear);
        }
        
        //directivaas que nada mas son 3 tipos ORG si reescribe su Hexadecimal
        
        if (linear.charAt(0)==' ') {
            String directiva = linear.trim();
            if (directiva.charAt(0) != '*') {
                String directivaAux = "";
                for (int i = 0; i < directiva.length(); i++) {
                    if (directiva.charAt(i) == ' ') {
                        break;
                    }
                    directivaAux += directiva.charAt(i);

                }
                if ("ORG".equals(directivaAux) || "END".equals(directivaAux) || "FCB".equals(directivaAux)) {
                    modificarDirectiva(linear);
                }
            }
            
        }
        
        // inherentes 8,1 152,1
        String aux=linear.trim();
        String mnemorico="";
        for(int i=0; i<aux.length(); i++){
            if(aux.charAt(i)==' '){
                break;
            }
            mnemorico+=aux.charAt(i);
        }
        mnemorico=mnemorico.toLowerCase();
        for(int i=0; i<=144; i++){
            if(mnemorico.equals(Ficheros.hc11[i][0])){
                System.out.println("Si existe en excel");
                break;
            }
        }
        
        
        
    }
    
    
   // metodos que modifican el atributo linea
   public void modificarComentario(String line){
        linear="          "+line;
            
   }
    public void modificarVariable(String line){
        String variable="", hexadecimal="", comentario="";
            int i;
            for(i=0;i<line.length();i++){
                if(line.charAt(i)==' '){
                    break;
                }
                variable += line.charAt(i);
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='$'){
                    line=line.substring(i+1,line.length());
                    
                }
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='*'){
                    comentario=line.substring(i,line.length());
                    break;
                }
                hexadecimal+=line.charAt(i);
            }
            hexadecimal=hexadecimal.trim();
            Ficheros.variables.add(variable);
            Ficheros.variablesH.add(hexadecimal);
            linear = "    "+hexadecimal+"    "+variable+"    "+"EQU"+"    $"+hexadecimal+comentario;
    }
    public void modificarDirectiva(String line) {
        line = line.trim();
        String directiva = "", hexadecimal = "", comentario = "";
        int i;
        for (i = 0; i < line.length(); i++) {
            if (line.charAt(i) == ' ') {
                break;
            }
            directiva += line.charAt(i);
        }
        for (i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '$') {
                line = line.substring(i + 1, line.length());
                break;

            }
        }
        for (i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '*') {
                comentario = line.substring(i, line.length());
                break;
            }
            hexadecimal += line.charAt(i);
        }
        hexadecimal = hexadecimal.trim();
        if (hexadecimal.equals("END")) {
            hexadecimal = "";
            linear = "      " + "    " + "            "+ directiva + "    " + hexadecimal + comentario;
            Ficheros.fin = "finDeCodigo";

        } else {
            if (directiva.toUpperCase().equals("ORG")) {
                linear = "      " + hexadecimal + "            " + directiva + "    $" + hexadecimal + comentario;
                Ficheros.celda = hexadecimal;

            } else {
                if (directiva.toUpperCase().equals("END")) {
                    linear = "      " + "    " + "            " + directiva + "    $" + hexadecimal + comentario;
                    Ficheros.fin = "finDeCodigo";
                } else {
                    if (directiva.toUpperCase().equals("FCB")) {
                        String hexadecimalFCB = "";
                        for (i = 0; i < hexadecimal.length(); i++) {
                            if (hexadecimal.charAt(i) != '$' && hexadecimal.charAt(i) != ' ') {
                                hexadecimalFCB += hexadecimal.charAt(i);
                            }
                        }
                        linear = " " + Ficheros.celda + " " + hexadecimalFCB + "            " + directiva + "    $" + hexadecimal + comentario;
                    }
                }
            }

        }

    }
    public void modificarEtiqueta(String line){
        String etiqueta="", comentario="";
        for(int i=0; i<line.length();i++){
            if(line.charAt(i)=='*'){
                comentario=line.substring(i,line.length());
                break;
            }
            etiqueta+=line.charAt(i);
            etiqueta=etiqueta.trim();
        }
        linear=" "+Ficheros.celda+"        "+line+comentario;
        Ficheros.etiquetas.add(etiqueta);
        Ficheros.etiquetasH.add(Ficheros.celda);
    }
    
    public String celdaExcel(int vRow, int vColumn) {
        String value = null;          //variable for storing the cell value  
        Workbook wb = null;           //initialize Workbook null  
        try {

            FileInputStream fis = new FileInputStream("68HC11.xlsx");
 
            wb = new XSSFWorkbook(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        Sheet sheet = wb.getSheetAt(0);   //getting the XSSFSheet object at given index  
        Row row = sheet.getRow(vRow); //returns the logical row  
        Cell cell = row.getCell(vColumn); //getting the cell representing the given column  
        try {
            value = cell.getStringCellValue();    //getting cell value  
        } catch (IllegalStateException e) {
            value = String.valueOf((int) cell.getNumericCellValue());
        }
        return value;               //returns the cell value  
    }
    
    
}

