
package ficheros;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileInputStream;  
import java.io.FileNotFoundException;  
import java.io.IOException;  
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.*;  
import org.apache.poi.ss.usermodel.Sheet;  
import org.apache.poi.ss.usermodel.Workbook;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook; 
public class Analizar {
    String linear="";
    
    public void verificarCode(String linea){
        this.linear=linea;
        Pattern comentarioP = Pattern.compile("^ *\\*+.*$");
        Matcher comentarioM = comentarioP.matcher(linear);
        Pattern variableP = Pattern.compile("^[^ *]+ +EQU +\\$[0-9A-F]{4}?( *\\*+.*)?$");
        Matcher variableM = variableP.matcher(linear);
        Pattern directivaP = Pattern.compile("^ +(ORG|END|FCB) +\\$[0-9A-F]{4}?( *\\*+.*)?$");// Tiene que se un numero hexadecimal?
        Matcher directivaM = directivaP.matcher(linear);
        Pattern etiquetaP = Pattern.compile("^[^ *]+( *\\*+.*)?$");
        Matcher etiquetaM = etiquetaP.matcher(linear);
        //modos de direccionamiento
        
        Pattern inherenteP = Pattern.compile("^ +[^ *]+( *\\*+.*)?$");
        Matcher inherenteM = inherenteP.matcher(linear);
        /*Pattern inmediatoP = Pattern.compile("^ +[^ *]+ +#((\\$(([0-9A-F]{2})|([0-9A-F]{4})))|('[\\p{ASCII}]{1,2})|(([\\d]{2})|([\\d]{4})))( *\\*+.*)?$");
        Matcher inmediatoM = inmediatoP.matcher(linear);
        */
        
        Pattern directoP = Pattern.compile("^ +[^ *]+ +((\\$[0-9A-F]{2})|(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])))( *\\*+.*)?$");
        Matcher directoM = directoP.matcher(linear);
        
        Pattern extendidoP = Pattern.compile("^ +[^ *]+ +((\\$([0-9A-F]{4}))|([\\d]{3,5}))( *\\*+.*)?$");
        Matcher extendidoM = extendidoP.matcher(linear); 
        Pattern indexadoP = Pattern.compile("^ +[^ *]+ +\\\\$([0-9A-F]{2})\\\\,(X|Y|x|y)( *\\\\*+.*)?$");
        Matcher indexadoM = indexadoP.matcher(linear);  
        Pattern relativoP = Pattern.compile("^ +[^ *]+ +[^ *]+( *\\*+.*)?$");
        Matcher relativoM = relativoP.matcher(linear);
        
        //Faltaria las 4 exepciones. 
        
        //verifica si es una linea nula no es necesario hacer nada se agrega las lineas nulas
        if(linear.trim().equals("")){
            linear=" 0000";
        }
        //Verificación de codigo
        if(comentarioM.matches()){
            modificarComentario(linear);
        }
        
        
        //variable y constantes y gardarlo
        if(variableM.matches()){
            modificarVariable(linear);
            
            
        }
        
        //verificar si es una etiqueta
        if(etiquetaM.matches()){
            modificarEtiqueta(linear);
        }
        
        //directivaas que nada mas son 3 tipos ORG si reescribe su Hexadecimal
        if(linear.contains("RESET ")){
           int x=linear.indexOf('F');
           int y=linear.indexOf('$');
           String directivaAux=linear.substring(x,y).trim();
           modificarDirectiva(linear);
        }
        
        if (linear.charAt(0)==' ') {
            String directiva = linear.trim();
            if (directiva.charAt(0) != '*') {
                String directivaAux = "";
                for (int i = 0; i < directiva.length(); i++) {
                    if (directiva.charAt(i) == ' ') {
                        break;
                    }
                    directivaAux += directiva.charAt(i);

                }
                if ("ORG".equals(directivaAux) || "END".equals(directivaAux) || "FCB".equals(directivaAux)) {
                    modificarDirectiva(linear);
                }
            }
            
        }
        
        // inherentes 8,1 152,1
        if(inherenteM.matches()){
            String aux = linear.trim();
            String mnemorico = "";
            for (int i = 0; i < aux.length(); i++) {
                if (aux.charAt(i) == ' ' || aux.charAt(i)=='*') {
                    break;
                }
                mnemorico += aux.charAt(i);
            }
            mnemorico = mnemorico.toLowerCase();
            for (int i = 0; i <= 144; i++) {
                if (mnemorico.equals(Ficheros.hc11[i][0])) {

                    if (!Ficheros.hc11[i][6].equals("--")) {
                        modificarInherente(i);
                    }
                }
            }
        }
        
        //MD Inmediato
        
        if(linear.contains("#") && linear.charAt(0)==' '){
            String aux = linear.trim();
            String mnemorico = "";
            for (int i = 0; i < aux.length(); i++) {
                if (aux.charAt(i) == ' ') {
                    break;
                }
                mnemorico += aux.charAt(i);
            }
            mnemorico = mnemorico.toLowerCase();
            for (int i = 0; i <= 144; i++) {
                if (mnemorico.equals(Ficheros.hc11[i][0])) {
                    if (!Ficheros.hc11[i][1].equals("--")) {
                        modificarInmediato(i);
                    }
                }
            }
        }
        
        // MD directo 
        
        if(!linear.contains("#") && linear.charAt(0)==' '){
            String aux = linear.trim(); //LDAA $12   *carga a A
            String mnemorico = "";
            String operando = "";
            String comentario = "";
            
            for (int i = 0; i < aux.length(); i++) {
                if (aux.charAt(i) == ' ') {
                    operando=aux.substring(i).trim();
                    break;
                }
                mnemorico += aux.charAt(i);
            }
            mnemorico = mnemorico.toLowerCase();  //shen $12
            for (int i = 0; i <= 144; i++) {
                    if (mnemorico.equals(Ficheros.hc11[i][0])) {
                        if (!Ficheros.hc11[i][2].equals("--")) {
                            mnemorico=Ficheros.hc11[i][2];
                            if (operando.contains("*")) {
                                comentario = operando.substring(operando.indexOf('*'));
                                operando = operando.substring(0, operando.indexOf('*')).trim();
                            }
                            System.out.println(operando);
                            if (!operando.contains(",")) {
                                if (operando.contains("$")) {
                                    operando = operando.substring(1);
                                    operando = String.valueOf((Integer.parseInt(operando)));
                                    if (operando.length() == 2) {
                                        modificarDirecto(mnemorico,operando,1);   
                                    }
                                } else {
                                    if (operando.contains(String.valueOf((char) 39))) {
                                        operando = operando.substring(1);
                                        int ascii = operando.charAt(0);
                                        operando = Integer.toHexString(ascii).toUpperCase();
                                        modificarDirecto(mnemorico,operando,1);
                                    } else {
                                        if (Ficheros.variables.contains(operando)) {
                                            operando = Ficheros.variablesH.get(Ficheros.variables.indexOf(operando));
                                            operando = String.valueOf((Integer.parseInt(operando)));
                                            if (operando.length() == 2) {
                                                modificarDirecto(mnemorico,operando,1);   
                                            }
                                        } else {
                                            Pattern numeroP = Pattern.compile("^[0-9]+$");
                                            Matcher numeroM = numeroP.matcher(operando);
                                            if(numeroM.matches()){
                                                operando = Integer.toHexString(Integer.parseInt(operando));
                                                if (operando.length() == 2) {
                                                    modificarDirecto(mnemorico,operando,1);   
                                                }
                                            }else{
                                                  modificarDirecto(mnemorico,operando,0);
                                                
                                            }
                                            

                                        }
                                    }

                                }

                            }
                        }
                    }
                }
            
        
        
        
        
        
    }
    }
    
    public void modificarDirecto(String mn, String op, int n){
        if (n == 1) {
            linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + mn + " " + op + "          " + linear.trim();
            int numopc = mn.length();
            int numopr = op.length();
            if (numopc == 2 && numopr == 2) {
                Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 2);
            } else {
                Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 3);
            }
        }else{
            Ficheros.error = true;
            Ficheros.error002 = true;
        }
        
        
    }
    
    public void modificarInmediato(int i){
        String opcode = Ficheros.hc11[i][1];
        String mnemonico = Ficheros.hc11[i][0].toUpperCase();
        String comentario = "";
        String operando = linear.substring(linear.indexOf('#')+1).trim();
        if (linear.contains("*")) {
            comentario = linear.substring(linear.indexOf('*'));
            operando = linear.substring(linear.indexOf('#')+1, linear.indexOf('*')).trim();
            
        }
        if(operando.charAt(0)=='$'){
            operando = operando.substring(operando.indexOf('$')+1);
            linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + opcode + " "+operando +"         "+ mnemonico + "    #$"+operando + comentario;
            
        }else{
          if(operando.charAt(0)==(char)39){
              char operandoO = operando.charAt(1);
              int ascii = (int)operando.charAt(1);
              operando = Integer.toHexString(ascii).toUpperCase();
              linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + opcode + " "+operando +"         "+ mnemonico + "    #'"+operandoO + comentario;
          }else{
              Pattern numeroP = Pattern.compile("^[0-9]+$");
              Matcher numeroM = numeroP.matcher(operando);
              if(numeroM.matches()){
                  String operandoO = operando;
                  operando = Integer.toHexString(Integer.parseInt(operando));
                  linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + opcode + " "+operando +"         "+ mnemonico + "    #"+operandoO + comentario;
              }else{
                  if(Ficheros.variables.contains(operando)){
                      int operandoAUX = Ficheros.variables.indexOf(operando);
                      operando = Ficheros.variablesH.get(operandoAUX);
                      linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + opcode + " "+operando +"         "+ mnemonico + "    #$"+Ficheros.variables.get(operandoAUX) + comentario;
                  }else{
                      Ficheros.error = true;
                      Ficheros.error001 = true;
                      
                  }
              }
              
          }  
        }
        int numopc = opcode.length();
        int numopr = operando.length();
        if (Ficheros.error == false) {
            if (numopc == 2 && numopr == 2) {
                Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 2);
            } else {
                if (numopc == 2 && numopr == 4 || numopc == 4 && numopr == 2) {
                    Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 3);
                } else {
                    Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 4);
                }

            }
        }
        
    }
    
    public void modificarInherente(int i){
        String opcode = Ficheros.hc11[i][6];
        String mnemonico = Ficheros.hc11[i][0].toUpperCase();
        String comentario = "";
        if(linear.contains("*")){
            comentario = linear.substring(linear.indexOf('*'));
        }
        int numopc = opcode.length();
        linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)) + " " + opcode + "            " + mnemonico + "    " + comentario;    
        if (numopc == 2) {
            Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 1);
        } else {
            Ficheros.celda = String.valueOf(Integer.parseInt(Ficheros.celda) + 2);
        }

            
    }
    
   // metodos que modifican el atributo linea
   public void modificarComentario(String line){
        linear="          "+line;
            
   }
    public void modificarVariable(String line){
        String variable="", hexadecimal="", comentario="";
            int i;
            for(i=0;i<line.length();i++){
                if(line.charAt(i)==' '){
                    break;
                }
                variable += line.charAt(i);
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='$'){
                    line=line.substring(i+1,line.length());
                    
                }
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='*'){
                    comentario=line.substring(i,line.length());
                    break;
                }
                hexadecimal+=line.charAt(i);
            }
            hexadecimal=hexadecimal.trim();
            Ficheros.variables.add(variable);
            Ficheros.variablesH.add(hexadecimal);
            linear = "    "+hexadecimal+"    "+variable+"    "+"EQU"+"    $"+hexadecimal+comentario;
    }
    public void modificarDirectiva(String line) {
        line = line.trim();
        String directiva = "", hexadecimal = "", comentario = "";
        int i;
        //FCB con reset
        if(linear.contains("RESET ")){
           directiva=linear.substring(linear.indexOf('F'),linear.indexOf('$')-1).trim();
           hexadecimal=linear.substring(linear.indexOf('$')+1,linear.indexOf(','))+linear.substring(linear.indexOf(',')+2,linear.indexOf(',')+4);
           String hexadecimal2=linear.substring(linear.indexOf('$'),linear.indexOf('$')+7);
           if(linear.contains("*")){
               comentario=linear.substring(linear.indexOf('*')).trim();
           }
           linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + hexadecimal + "    RESET   " + directiva + "    " + hexadecimal2 + comentario;
           
        }else {
            for (i = 0; i < line.length(); i++) {
                if (line.charAt(i) == ' ') {
                    break;
                }
                directiva += line.charAt(i);
            }
            for (i = 0; i < line.length(); i++) {
                if (line.charAt(i) == '$') {
                    line = line.substring(i + 1, line.length());
                    break;

                }
            }
            for (i = 0; i < line.length(); i++) {
                if (line.charAt(i) == '*') {
                    comentario = line.substring(i, line.length());
                    break;
                }
                hexadecimal += line.charAt(i);
            }
            hexadecimal = hexadecimal.trim();
            if (hexadecimal.equals("END")) {
                hexadecimal = "";
                linear = "      " + "    " + "            " + directiva + "    " + hexadecimal + comentario;
                Ficheros.fin = "finDeCodigo";

            } else {
                if (directiva.toUpperCase().equals("ORG")) {
                    linear = "      " + hexadecimal + "            " + directiva + "    $" + hexadecimal + comentario;
                    Ficheros.celda = String.valueOf(Integer.parseInt(hexadecimal, 16));
                } else {
                    if (directiva.toUpperCase().equals("END")) {
                        linear = "      " + "    " + "            " + directiva + "    $" + hexadecimal + comentario;
                        Ficheros.fin = "finDeCodigo";
                    } else {
                        if (directiva.toUpperCase().equals("FCB")) {
                            String hexadecimalFCB = "";
                            for (i = 0; i < hexadecimal.length(); i++) {
                                if (hexadecimal.charAt(i) != '$' && hexadecimal.charAt(i) != ' ' && hexadecimal.charAt(i) != ',') {
                                    hexadecimalFCB += hexadecimal.charAt(i);
                                }
                            }
                            linear = " " + Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase() + " " + hexadecimalFCB + "            " + directiva + "    $" + hexadecimal + comentario;
                        }
                    }
                }

            }

        }


    }
    public void modificarEtiqueta(String line){
        String etiqueta="", comentario="";
        for(int i=0; i<line.length();i++){
            if(line.charAt(i)=='*'){
                comentario=line.substring(i,line.length());
                break;
            }
            etiqueta+=line.charAt(i);
            etiqueta=etiqueta.trim();
        }
        linear=" "+Integer.toHexString(Integer.parseInt(Ficheros.celda)).toUpperCase()+"        "+line+comentario;
        Ficheros.etiquetas.add(etiqueta);
        Ficheros.etiquetasH.add(Ficheros.celda);
    }
    
    /*public String celdaExcel(int vRow, int vColumn) {
        String value = null;          //variable for storing the cell value  
        Workbook wb = null;           //initialize Workbook null  
        try {

            FileInputStream fis = new FileInputStream("68HC11.xlsx");
 
            wb = new XSSFWorkbook(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        Sheet sheet = wb.getSheetAt(0);   //getting the XSSFSheet object at given index  
        Row row = sheet.getRow(vRow); //returns the logical row  
        Cell cell = row.getCell(vColumn); //getting the cell representing the given column  
        try {
            value = cell.getStringCellValue();    //getting cell value  
        } catch (IllegalStateException e) {
            value = String.valueOf((int) cell.getNumericCellValue());
        }
        return value;               //returns the cell value  
    }*/
    
    
}

