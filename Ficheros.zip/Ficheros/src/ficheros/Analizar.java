
package ficheros;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Analizar {
    String linear="";
    
    public void verificarCode(String linea){
        this.linear=linea;
        Pattern comentarioP = Pattern.compile("^ *\\*+.*$");
        Matcher comentarioM = comentarioP.matcher(linear);
        Pattern variableP = Pattern.compile("^[^ *]+ +EQU +\\$[0-9A-F]{4}?( *\\*+.*)?$");
        Matcher variableM = variableP.matcher(linear);
        Pattern constanteP = Pattern.compile("^[^ *]+ +EQU +#\\$[0-9A-F]{4}?( *\\*+.*)?$");
        Matcher constanteM = constanteP.matcher(linear);
        Pattern directivaP = Pattern.compile("^ +(ORG|END|FCB) +\\$[0-9A-F]{4}?( *\\*+.*)?$");// Tiene que se un numero hexadecimal?
        Matcher directivaM = directivaP.matcher(linear);
        Pattern etiquetaP = Pattern.compile("^[^ *]+( *\\*+.*)?$");
        Matcher etiquetaM = etiquetaP.matcher(linear);
        //modos de direccionamiento
        
        Pattern inherenteP = Pattern.compile("^ +[^ *]+( *\\*+.*)?$");
        Matcher inherenteM = inherenteP.matcher(linear);
        Pattern inmediatoP = Pattern.compile("^ +[^ *]+ +#((\\$(([0-9A-F]{2})|([0-9A-F]{4})))|('[\\p{ASCII}]{1,2})|(([\\d]{2})|([\\d]{4})))( *\\*+.*)?$");
        Matcher inmediatoM = inmediatoP.matcher(linear);
        Pattern directoP = Pattern.compile("^ +[^ *]+ +((\\$[0-9A-F]{2})|(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])))( *\\*+.*)?$");
        Matcher directoM = directoP.matcher(linear);
        Pattern extendidoP = Pattern.compile("^ +[^ *]+ +((\\$([0-9A-F]{4}))|([\\d]{3,5}))( *\\*+.*)?$");
        Matcher extendidoM = extendidoP.matcher(linear); 
        Pattern indexadoP = Pattern.compile("^ +[^ *]+ +\\\\$([0-9A-F]{2})\\\\,(X|Y|x|y)( *\\\\*+.*)?$");
        Matcher indexadoM = indexadoP.matcher(linear);  
        Pattern relativoP = Pattern.compile("^ +[^ *]+ +[^ *]+( *\\*+.*)?$");
        Matcher relativoM = relativoP.matcher(linear);
        
        //Faltaria las 4 exepciones. 
        
        //verifica si es una linea nula no es necesario hacer nada se agrega las lineas nulas
        if(linear.trim().equals("")){
            linear=" 0000";
        }
        //Verificación de codigo
        if(comentarioM.matches()){
            modificarComentario(linear);
        }
        
        
        //variable y gardarlo
        if(variableM.matches()){
            modificarVariable(linear);
            
            
        }
        //constantes y guardarlo
        if(constanteM.matches()){
            modificarConstante(linear);
        }
        
        //directivaas que nada mas son 3 tipos ORG si reescribe su Hexadecimal
        if(directivaM.matches()){
            modificarDirectiva(linear);
        }
        //verificar si es una etiqueta
        if(etiquetaM.matches()){
            modificarEtiqueta(linear);
        }
    }
    
    
   // metodos que modifican el atributo linea
   public void modificarComentario(String line){
        linear="          "+line;
            
   }
    public void modificarVariable(String line){
        String origina=line;
        String variable="", hexadecimal="";
            int i;
            for(i=0;i<line.length();i++){
                if(line.charAt(i)==' '){
                    break;
                }
                variable += line.charAt(i);
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='$'){
                    line=line.substring(i+1,line.length());
                    
                }
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='*'){
                    break;
                }
                hexadecimal+=line.charAt(i);
            }
            hexadecimal=hexadecimal.trim();
            Ficheros.variables.add(variable);
            Ficheros.variablesH.add(hexadecimal);
            linear = "    "+hexadecimal+"    "+origina;
    }
    public void modificarConstante(String line){
        String origina=line;
        String constante="", hexadecimal="";
            int i;
            for(i=0;i<line.length();i++){
                if(line.charAt(i)==' '){
                    break;
                }
                constante += line.charAt(i);
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='$'){
                    line=line.substring(i+1,line.length());
                   
                }
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='*'){
                    break;
                }
                hexadecimal+=line.charAt(i);
            }
            hexadecimal=hexadecimal.trim();
            Ficheros.constantes.add(constante);
            Ficheros.constantesH.add(hexadecimal);
            linear = "    "+hexadecimal+"    "+origina;
    }
    public void modificarDirectiva(String line){
        String origina=line;
        line=line.trim();
        String directiva="", hexadecimal="";
            int i;
            for(i=0;i<line.length();i++){
                if(line.charAt(i)==' '){
                    break;
                }
                directiva += line.charAt(i);
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='$'){
                    line=line.substring(i+1,line.length());
                   
                }
            }
            for(i=0;i<line.length();i++){
                if(line.charAt(i)=='*'){
                    break;
                }
                hexadecimal+=line.charAt(i);
            }
            hexadecimal=hexadecimal.trim();
            if(directiva.toUpperCase().equals("ORG")){
                linear = "    "+hexadecimal+"    "+origina;
                Ficheros.celda=hexadecimal;
            }
            if(directiva.toUpperCase().equals("END")){
                linear = "    "+"   "+"     "+origina;
                Ficheros.fin="finDeCodigo";
            }
            else{
                linear = "    "+"   "+"     "+origina;
            }
    }
    public void modificarEtiqueta(String line){
        String etiqueta="";
        for(int i=0; i<line.length();i++){
            if(line.charAt(i)==' '){
                    break;
            }
            etiqueta+=line.charAt(i);
        }
        linear=" "+Ficheros.celda+"    "+line;
        Ficheros.etiquetas.add(etiqueta);
        Ficheros.etiquetasH.add(Ficheros.celda);
    }
}
