/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficheros;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author shens
 */
public class Ficheros {
    static String nombreArchivoR; //Nombre de archivo de entrada
    static String nombreArchivoE; //Nombre de archivo de salida
    static String linea; // linea que voy a analizar
    static int contadorLinea=0; // contador de linea que voy a analizar
    static int totalLinea=0;
    static ArrayList<String> variables=new ArrayList<String>();
    static ArrayList<String> variablesH=new ArrayList<String>();
    static ArrayList<String> constantes=new ArrayList<String>();
    static ArrayList<String> constantesH=new ArrayList<String>();
 
    
    
    public static void main(String[] args) {
        
        //expresiones regulares 
      
        
        // pedir nombre de archivo que esta en el escritorio
        nombreArchivoR = JOptionPane.showInputDialog("Ingresar la ruta del archivo(*.ASC):");
        File archivoR = new File(nombreArchivoR);//tiene que estar en la carpeta de ficheros
        
        //cambia la terminacion del archivo de salida
        int longitud=nombreArchivoR.length();
        nombreArchivoE=nombreArchivoR.substring(0, longitud-4)+".LST";
        File archivoE = new File(nombreArchivoE);
        
        if(archivoR.exists()==true){//verifica que existe el archivo
            try {
                archivoE.createNewFile();// crea el archivo de salida
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "No se pudo crear el archivo");
            }
            
            // Aqui empieza todo el proceso
            
            Leer read = new Leer();// para leer el archivo linea por linea
            Leer read1 = new Leer();//para saber cuantos lineas hay en el archivo
            Escribir write = new Escribir();
            
            totalLinea=read1.totalLineas(archivoR.getAbsolutePath());
            System.out.println(totalLinea);
            
            Analizar ana =new Analizar();
            
            for(int i=1;i<=totalLinea;i++){
                read.leer(archivoR.getAbsolutePath(),i);
                linea=read.linea;
                ana.verificarCode(linea);
                linea=ana.linear;
                linea=String.valueOf(i)+" A"+linea;
                write.escribir(archivoE.getAbsolutePath(), linea);
           }
            
            System.out.println("Variables");
            System.out.println(variables);
            System.out.println(variablesH);
            System.out.println("Constantes");
            System.out.println(constantes);
            System.out.println(constantesH);
            
            
        }else{
            JOptionPane.showMessageDialog(null, "No se encontro el archivo");
        }
        
    }
    
    
}

