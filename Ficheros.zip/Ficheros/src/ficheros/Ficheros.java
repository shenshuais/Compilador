/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficheros;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author shens
 */
public class Ficheros {
    static String nombreArchivoR; //Nombre de archivo de entrada
    static String nombreArchivoE; //Nombre de archivo de salida
    static String linea; // linea que voy a analizar
    static int contadorLinea=0; // contador de linea que voy a analizar
    static int totalLinea=0;
    static ArrayList<String> variables=new ArrayList<String>();
    static ArrayList<String> variablesH=new ArrayList<String>();
    static ArrayList<String> etiquetas=new ArrayList<String>();
    static ArrayList<String> etiquetasH=new ArrayList<String>();
    static String celda="0000";
    static String fin="";
    static boolean error = false;
    static boolean error001 = false; //CONSTANTE INEXCISTENTE 
    static boolean error002 = false; //VARIABLE INEXCISTENTE
    
    
    static String hc11[][] = null;
 
    
    
    public static void main(String[] args) {
        
        //expresiones regulares 
      
        
        // pedir nombre de archivo que esta en el escritorio
        nombreArchivoR = JOptionPane.showInputDialog("Ingresar la ruta del archivo(*.ASC):");
        File archivoR = new File(nombreArchivoR);//tiene que estar en la carpeta de ficheros
        
        //cambia la terminacion del archivo de salida
        int longitud=nombreArchivoR.length();
        nombreArchivoE=nombreArchivoR.substring(0, longitud-4)+".LST";
        File archivoE = new File(nombreArchivoE);
        
        if(archivoR.exists()==true){//verifica que existe el archivo
            try {
                archivoE.createNewFile();// crea el archivo de salida
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "No se pudo crear el archivo");
            }
            
            // Aqui empieza todo el proceso
            
            Leer read = new Leer();// para leer el archivo linea por linea
            Leer read1 = new Leer();//para saber cuantos lineas hay en el archivo
            Escribir write = new Escribir();
            
            totalLinea=read1.totalLineas(archivoR.getAbsolutePath());
            Analizar ana =new Analizar();
            
            //llenar la tabla
            
            try
            {
                FileInputStream f1 = new FileInputStream("mc68hc11xlsx.ser");
                ObjectInputStream o1 = new ObjectInputStream(f1);

                hc11 = (String[][]) o1.readObject();

                o1.close();
                f1.close();

            } catch (IOException e) {
                System.out.println("IOException caught");
            } catch (ClassNotFoundException c) {
                System.out.println("ClassNotFoundException caught");
            }
            
            //printStringArray(hc11,145,8);
            
            for(int i=1;i<=totalLinea;i++){
                read.leer(archivoR.getAbsolutePath(),i);
                linea=read.linea;
                ana.verificarCode(linea);
                linea=ana.linear;
                linea=String.valueOf(i)+" A"+linea;
                write.escribir(archivoE.getAbsolutePath(), linea);
                if(error == true){
                    if(error001 == true){
                        write.escribir(archivoE.getAbsolutePath()," E            ^ERROR 001 CONSTANTE INEXISTENTE");
                    }
                    error = false;
                    error001 = false;
                    if(error002 == true){
                        write.escribir(archivoE.getAbsolutePath()," E            ^ERROR 002 VARIABLE INEXISTENTE");
                    }
                    error = false;
                    error002 = false;
                    
                }
                if(fin.equals("finDeCodigo")){
                    break;
                }
           }
            //podemos verificar aqui si la ultima linea es END
            
            
            
            
            
            System.out.println("Variables");
            System.out.println(variables);
            System.out.println(variablesH);
            System.out.println("Etiqurtas");
            System.out.println(etiquetas);
            System.out.println(etiquetasH);
            System.out.println(celda);
            
            /*Analizar ana1 = new Analizar();
            System.out.println(ana1.celdaExcel(19, 2));*/
            
            
        }else{
            JOptionPane.showMessageDialog(null, "No se encontro el archivo");
        }
        
    }
    /*public static void printStringArray(String[][] s, int m, int n){
        for(int i=0; i<m; i++){
            for(int j=0; j<n;j++){
                System.out.print(s[i][j]+"    ");
            }
            System.out.println();
        }
    }*/
    
}

